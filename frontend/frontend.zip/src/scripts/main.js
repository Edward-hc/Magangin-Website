import '../styles/tailwind.css';
import '../styles/styles.css';
import App from './pages/app';
import swRegister from './registerSW';

const app = new App();

if (!window.location.hash) {
  window.location.hash = '/';
}

window.addEventListener('hashchange', () => {
  app.renderPage();
});

window.addEventListener('load', () => {
  app.renderPage();
  swRegister();
});
