import HomePage from './pages/home-page.js';

const routes = {
  '/': HomePage,
  '#home': HomePage,
  'home': HomePage,
  // route lainnya
};

export default routes;